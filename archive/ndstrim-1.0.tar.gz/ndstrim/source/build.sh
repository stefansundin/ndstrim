#!/bin/sh
gcc -o ndstrim ndstrim.c
strip ndstrim

